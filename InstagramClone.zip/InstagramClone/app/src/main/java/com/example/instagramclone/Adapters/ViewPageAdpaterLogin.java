package com.example.instagramclone.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.instagramclone.LoginActivityFragments.LoginFragment;
import com.example.instagramclone.LoginActivityFragments.RegisterFragment;

public class ViewPageAdpaterLogin extends FragmentStatePagerAdapter {

    int numOfTabs;

    public ViewPageAdpaterLogin(FragmentManager fm) {
        super(fm);
    }

    public ViewPageAdpaterLogin(FragmentManager fm, int numOfTabs) {
        super(fm);
        this.numOfTabs = numOfTabs;
    }

    @Override
    public Fragment getItem(int i) {

        switch (i) {
            case 0:
                LoginFragment loginFragment = new LoginFragment();
                return loginFragment;
            case 1:
                RegisterFragment registerFragment = new RegisterFragment();
                return registerFragment;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return numOfTabs;
    }
}
